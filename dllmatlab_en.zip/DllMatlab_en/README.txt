//+------------------------------------------------------------------+
//|                                                 MatlabEngineLib  |
//|                        Copyright 2010, MetaQuotes Software Corp. |
//|                                           http://www.mql5.com/ru |
//+------------------------------------------------------------------+

32-bit folder contains:

1. 32-bit version of Dll.
2. Library source code.
3. Library check script.
4. All files to run Dll (Dll-import).