//+------------------------------------------------------------------+
//|                                                 MatlabReducerLib |
//|                        Copyright 2010, MetaQuotes Software Corp. |
//|                                           http://www.mql5.com/ru |
//+------------------------------------------------------------------+

This archive contains all needed files to build/debug/use of MATLAB 7 library.

Files:                        - needed to build project in your C++ compiler.
nSMA.cpp, 
nSMA.def,
NEOSMA.h
NEOSMA.lib 
mclmcr.h

Files from Libraries folder      - place to: <Terminal_dir>\MQL5\Libraries

Files from Scripts folder        - place to: <Terminal_dir>\MQL5\Scripts

Files from Windows folder        - place to: <Windows_dir>

Files from MATLAM-Scripts folder -  m-functions source codes.